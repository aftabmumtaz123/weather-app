import express from "express";
import fetch from "node-fetch";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.use(express.static("public"));

function getRandomBgClass() {
    const classes = ['bg-random-1', 'bg-random-2', 'bg-random-3', 'bg-random-4', 'bg-random-5', 'bg-random-6'];
    return classes[Math.floor(Math.random() * classes.length)];
}

// Route to serve the weather page with the form
app.get('/', async (req, res) => {
    const city = req.query.city || 'Islamabad';
    const apiKey = "324295f34cafd5f257c05e7c542c4059";
         try {
        const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`);
        const data = await response.json();
        if (data.cod === 200) {
            const randomBgClass = getRandomBgClass();
            res.render('weather', { data, selectedCity: city, randomBgClass });
        } else {
            res.send(`Error: ${data.message}`);
        }
    } catch (error) {
        res.render('weather', { selectedCity: city, randomBgClass });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
